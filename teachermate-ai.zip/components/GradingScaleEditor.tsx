import React from 'react';
import { GradingScaleItem } from '../types';
import { Trash2, Plus } from 'lucide-react';

interface Props {
  scale: GradingScaleItem[];
  onChange: (scale: GradingScaleItem[]) => void;
}

export const GradingScaleEditor: React.FC<Props> = ({ scale, onChange }) => {
  const handleUpdate = (index: number, field: keyof GradingScaleItem, value: string | number) => {
    const newScale = [...scale];
    newScale[index] = { ...newScale[index], [field]: value };
    onChange(newScale);
  };

  const handleDelete = (index: number) => {
    const newScale = scale.filter((_, i) => i !== index);
    onChange(newScale);
  };

  const handleAdd = () => {
    onChange([...scale, { minPercentage: 0, maxPercentage: 0, grade: '?', label: '' }]);
  };

  return (
    <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
      <h3 className="font-semibold text-slate-700 mb-3">Grading Scale Configuration</h3>
      
      {/* Desktop Header */}
      <div className="hidden md:grid grid-cols-12 gap-2 text-xs font-medium text-slate-500 uppercase mb-2">
        <div className="col-span-2">Min %</div>
        <div className="col-span-2">Max %</div>
        <div className="col-span-3">Grade</div>
        <div className="col-span-4">Label (Optional)</div>
        <div className="col-span-1"></div>
      </div>

      <div className="space-y-3 md:space-y-2">
        {scale.map((item, index) => (
          <div key={index} className="grid grid-cols-6 md:grid-cols-12 gap-2 items-center bg-slate-50 md:bg-transparent p-3 md:p-0 rounded-md md:rounded-none border md:border-none border-slate-100">
            
            <div className="col-span-2 md:col-span-2">
               <label className="md:hidden text-xs text-slate-400 block mb-1">Min %</label>
               <input
                type="number"
                value={item.minPercentage}
                onChange={(e) => handleUpdate(index, 'minPercentage', Number(e.target.value))}
                className="w-full p-2 border rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="col-span-2 md:col-span-2">
              <label className="md:hidden text-xs text-slate-400 block mb-1">Max %</label>
              <input
                type="number"
                value={item.maxPercentage}
                onChange={(e) => handleUpdate(index, 'maxPercentage', Number(e.target.value))}
                className="w-full p-2 border rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="col-span-2 md:col-span-3">
              <label className="md:hidden text-xs text-slate-400 block mb-1">Grade</label>
              <input
                type="text"
                value={item.grade}
                onChange={(e) => handleUpdate(index, 'grade', e.target.value)}
                className="w-full p-2 border rounded text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
            
             <div className="col-span-5 md:col-span-4">
              <label className="md:hidden text-xs text-slate-400 block mb-1">Label</label>
               <input
                type="text"
                value={item.label || ''}
                placeholder="Label"
                onChange={(e) => handleUpdate(index, 'label', e.target.value)}
                className="w-full p-2 border rounded text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="col-span-1 md:col-span-1 flex justify-center md:justify-center items-end md:items-center h-full pb-1 md:pb-0">
              <button 
                onClick={() => handleDelete(index)}
                className="text-red-500 hover:text-red-700 bg-white md:bg-transparent p-2 md:p-0 rounded border md:border-none shadow-sm md:shadow-none"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
      <button
        onClick={handleAdd}
        className="mt-4 flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium bg-indigo-50 px-3 py-2 rounded-md transition-colors w-full md:w-auto justify-center md:justify-start"
      >
        <Plus size={16} /> Add Range
      </button>
    </div>
  );
};