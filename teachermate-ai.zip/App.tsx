import React, { useState, useRef } from 'react';
import { 
  BookOpen, 
  CheckCircle, 
  Upload, 
  PlusCircle, 
  FileText, 
  ChevronRight, 
  Loader2, 
  GraduationCap,
  History,
  Menu,
  X,
  Printer
} from 'lucide-react';
import { AppMode, ExamContext, GradingScaleItem, GradingResult } from './types';
import { fileToBase64 } from './utils';
import { GradingScaleEditor } from './components/GradingScaleEditor';
import * as GeminiService from './services/geminiService';

// Default Polish Grading Scale
const DEFAULT_POLISH_SCALE: GradingScaleItem[] = [
  { minPercentage: 0, maxPercentage: 30, grade: '1', label: 'Niedostateczny (F)' },
  { minPercentage: 31, maxPercentage: 50, grade: '2', label: 'Dopuszczający (D)' },
  { minPercentage: 51, maxPercentage: 70, grade: '3', label: 'Dostateczny (C)' },
  { minPercentage: 71, maxPercentage: 85, grade: '4', label: 'Dobry (B)' },
  { minPercentage: 86, maxPercentage: 95, grade: '5', label: 'Bardzo Dobry (A)' },
  { minPercentage: 96, maxPercentage: 100, grade: '6', label: 'Celujący (A+)' },
];

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [examHistory, setExamHistory] = useState<ExamContext[]>([]);
  
  // Current Exam State
  const [currentExam, setCurrentExam] = useState<ExamContext>({
    id: Date.now().toString(),
    title: 'New Exam',
    gradingScale: DEFAULT_POLISH_SCALE,
    answerKeyText: '',
  });

  // Creation State
  const [creationTopic, setCreationTopic] = useState('');
  const [creationMaterial, setCreationMaterial] = useState('');
  const [isGeneratingTest, setIsGeneratingTest] = useState(false);
  const [generatedTestContent, setGeneratedTestContent] = useState('');

  // Grading State
  const [gradingResult, setGradingResult] = useState<GradingResult | null>(null);
  const [isGrading, setIsGrading] = useState(false);
  const [studentFiles, setStudentFiles] = useState<File[]>([]);
  const [keyFiles, setKeyFiles] = useState<File[]>([]);

  // UI State
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Default closed on mobile

  // --- Handlers ---
  const handleNav = (newMode: AppMode) => {
    setMode(newMode);
    if (window.innerWidth < 768) {
      setIsSidebarOpen(false);
    }
  };

  const handleCreateTest = async () => {
    if (!creationTopic) return;
    setIsGeneratingTest(true);
    try {
      const result = await GeminiService.generateTestFromMaterial(
        creationTopic, 
        creationMaterial, 
        "Medium/High School"
      );
      
      setGeneratedTestContent(result.testContent);
      setCurrentExam(prev => ({
        ...prev,
        title: creationTopic,
        answerKeyText: result.answerKey,
        materialText: creationMaterial
      }));
    } catch (e) {
      alert("Failed to generate test. Please try again.");
      console.error(e);
    } finally {
      setIsGeneratingTest(false);
    }
  };

  const handleStartGradingFromCreation = () => {
    handleNav(AppMode.GRADING_SESSION);
  };

  const handleGradeStudent = async () => {
    if (studentFiles.length === 0) return;
    setIsGrading(true);
    setGradingResult(null);

    try {
      const studentBase64s = await Promise.all(studentFiles.map(fileToBase64));
      const keyBase64s = await Promise.all(keyFiles.map(fileToBase64));

      const result = await GeminiService.gradeStudentTest(
        currentExam.answerKeyText || '',
        keyBase64s,
        studentBase64s,
        currentExam.gradingScale
      );

      setGradingResult(result);
    } catch (e) {
      console.error(e);
      alert("Error grading test. Ensure API Key is set and images are clear.");
    } finally {
      setIsGrading(false);
    }
  };

  const handleNextStudent = () => {
    setStudentFiles([]);
    setGradingResult(null);
  };

  // --- Renderers ---

  const Sidebar = () => (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 z-20 bg-black/50 transition-opacity md:hidden ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} 
        onClick={() => setIsSidebarOpen(false)} 
      />
      
      {/* Sidebar Content */}
      <div className={`fixed md:relative z-30 h-full bg-slate-900 text-white transition-all duration-300 overflow-hidden flex flex-col 
        ${isSidebarOpen ? 'w-64 translate-x-0' : '-translate-x-full md:translate-x-0 md:w-64 w-64'}`}>
        
        <div className="p-4 border-b border-slate-700 flex justify-between items-center h-16">
          <h1 className="font-bold text-xl tracking-tight flex items-center gap-2">
            <GraduationCap className="text-indigo-400" />
            TeacherMate
          </h1>
          <button onClick={() => setIsSidebarOpen(false)} className="md:hidden">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          <button 
            onClick={() => {
              handleNav(AppMode.CREATE_TEST);
              setGeneratedTestContent('');
              setCreationTopic('');
            }}
            className="w-full flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white p-3 rounded-md transition-colors font-medium shadow-lg"
          >
            <PlusCircle size={18} /> Create New Test
          </button>
          
          <button 
            onClick={() => {
              handleNav(AppMode.SETUP_GRADING);
              setCurrentExam({
                id: Date.now().toString(),
                title: "Untitled Exam",
                gradingScale: DEFAULT_POLISH_SCALE,
                answerKeyText: ''
              });
              setKeyFiles([]);
            }}
            className="w-full flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 p-3 rounded-md transition-colors border border-slate-700"
          >
            <CheckCircle size={18} /> Grade Existing Test
          </button>

          <div className="mt-8">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2">
              <History size={12} /> Recent Sessions
            </h3>
            <div className="space-y-1">
              <div className="text-sm text-slate-400 p-2 hover:bg-slate-800 rounded cursor-pointer truncate">
                History Exam - Chapter 4
              </div>
              <div className="text-sm text-slate-400 p-2 hover:bg-slate-800 rounded cursor-pointer truncate">
                Math - Algebra Basics
              </div>
            </div>
          </div>
        </div>
        
        <div className="p-4 border-t border-slate-800 text-xs text-slate-500 text-center pb-8 md:pb-4">
          Powered by Gemini AI
        </div>
      </div>
    </>
  );

  const renderDashboard = () => (
    <div className="flex flex-col items-center justify-center h-full text-center p-4 md:p-8 bg-slate-50 overflow-y-auto">
      <div className="bg-white p-6 md:p-8 rounded-2xl shadow-xl max-w-lg w-full my-auto">
        <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <GraduationCap size={32} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Welcome, Teacher</h2>
        <p className="text-slate-600 mb-8">
          Save hours of grading time. Create exams instantly or upload student papers to get automated feedback and grades.
        </p>
        <div className="grid grid-cols-1 gap-4">
          <button 
            onClick={() => handleNav(AppMode.CREATE_TEST)}
            className="p-4 border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50 rounded-xl transition-all group text-left"
          >
            <div className="font-semibold text-slate-800 group-hover:text-indigo-700 flex items-center gap-2 mb-1">
              <PlusCircle size={18} /> Create Test
            </div>
            <p className="text-sm text-slate-500">Generate materials & answer keys from text.</p>
          </button>
           <button 
            onClick={() => handleNav(AppMode.SETUP_GRADING)}
            className="p-4 border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50 rounded-xl transition-all group text-left"
          >
            <div className="font-semibold text-slate-800 group-hover:text-indigo-700 flex items-center gap-2 mb-1">
              <CheckCircle size={18} /> Grade Papers
            </div>
            <p className="text-sm text-slate-500">Upload answer key and grade student scans.</p>
          </button>
        </div>
      </div>
    </div>
  );

  const renderCreateTest = () => (
    <div className="h-full overflow-y-auto p-4 md:p-10 max-w-5xl mx-auto">
      <div className="mb-6 mt-12 md:mt-0">
        <h2 className="text-2xl font-bold text-slate-800">Create New Exam</h2>
        <p className="text-slate-500">Provide materials and AI will generate the test for you.</p>
      </div>

      {!generatedTestContent ? (
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-200 space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Test Topic / Title</label>
            <input 
              type="text" 
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              placeholder="e.g., World War II History"
              value={creationTopic}
              onChange={(e) => setCreationTopic(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Source Material</label>
            <textarea 
              className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none h-48"
              placeholder="Paste the chapter text, notes, or article here..."
              value={creationMaterial}
              onChange={(e) => setCreationMaterial(e.target.value)}
            />
          </div>

          <button 
            onClick={handleCreateTest}
            disabled={!creationTopic || isGeneratingTest}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            {isGeneratingTest ? <Loader2 className="animate-spin" /> : <FileText />} 
            {isGeneratingTest ? 'Generating Test...' : 'Generate Exam & Answer Key'}
          </button>
        </div>
      ) : (
        <div className="space-y-6 animate-fade-in pb-20">
          <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-200">
             <div className="flex flex-col md:flex-row justify-between md:items-center mb-4 border-b pb-4 gap-2">
                <h3 className="text-lg font-bold text-indigo-900">Generated Exam Preview</h3>
                <div className="flex gap-2">
                   <button className="text-slate-500 hover:text-indigo-600 flex items-center gap-1 text-sm border px-3 py-1 rounded">
                      <Printer size={16}/> Print
                   </button>
                </div>
             </div>
             <div className="prose max-w-none text-slate-800 whitespace-pre-wrap font-serif bg-slate-50 p-4 md:p-6 rounded border border-slate-100 text-sm md:text-base">
               {generatedTestContent}
             </div>
          </div>

          <div className="flex flex-col md:flex-row justify-end gap-4">
            <button 
              onClick={() => setGeneratedTestContent('')} 
              className="px-6 py-3 text-slate-600 hover:text-slate-800 border rounded-lg md:border-none"
            >
              Back to Edit
            </button>
            <button 
              onClick={handleStartGradingFromCreation}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg flex items-center justify-center gap-2 shadow-lg hover:shadow-indigo-200/50 transition-all"
            >
              Use This to Grade Students <ChevronRight />
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderSetupGrading = () => (
    <div className="h-full overflow-y-auto p-4 md:p-10 max-w-4xl mx-auto pb-20">
       <div className="mb-6 mt-12 md:mt-0">
        <h2 className="text-2xl font-bold text-slate-800">Setup Grading Session</h2>
        <p className="text-slate-500">Configure correct answers and grading rules.</p>
      </div>

      <div className="space-y-6">
        <div className="bg-white p-4 md:p-6 rounded-xl shadow-sm border border-slate-200">
          <label className="block text-sm font-medium text-slate-700 mb-2">Answer Key Source</label>
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
               <span className="text-xs text-slate-500 mb-1 block">Option A: Upload Answer Key Image</span>
               <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:bg-slate-50 transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    onChange={(e) => setKeyFiles(Array.from(e.target.files || []))}
                  />
                  <Upload className="mx-auto text-slate-400 mb-2" />
                  <p className="text-sm text-slate-600">
                    {keyFiles.length > 0 ? `${keyFiles.length} file(s) selected` : 'Upload Photo'}
                  </p>
               </div>
            </div>
            <div className="flex items-center justify-center text-slate-400 font-medium">OR</div>
            <div className="flex-1">
              <span className="text-xs text-slate-500 mb-1 block">Option B: Paste Text Answer Key</span>
              <textarea 
                className="w-full h-28 p-3 border border-slate-300 rounded-lg text-sm"
                placeholder="1. A, 2. B, 3. The capital is Warsaw..."
                value={currentExam.answerKeyText || ''}
                onChange={(e) => setCurrentExam({...currentExam, answerKeyText: e.target.value})}
              />
            </div>
          </div>
        </div>

        <GradingScaleEditor 
          scale={currentExam.gradingScale}
          onChange={(newScale) => setCurrentExam({...currentExam, gradingScale: newScale})}
        />

        <div className="flex justify-end">
           <button 
              onClick={() => handleNav(AppMode.GRADING_SESSION)}
              className="w-full md:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-lg flex items-center justify-center gap-2"
            >
              Start Grading Session <ChevronRight />
            </button>
        </div>
      </div>
    </div>
  );

  const renderGradingSession = () => (
    <div className="h-full flex flex-col md:flex-row overflow-hidden">
      {/* Left: Input */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 border-b md:border-b-0 md:border-r border-slate-200 bg-white">
        <div className="mt-12 md:mt-0 mb-4">
          <h2 className="text-xl font-bold text-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-2">
            <span>Student Submission</span>
            <span className="text-xs md:text-sm font-normal text-slate-500 bg-slate-100 px-2 py-1 rounded inline-block w-fit">
              Scale: {currentExam.gradingScale[0].grade} - {currentExam.gradingScale[currentExam.gradingScale.length-1].grade}
            </span>
          </h2>
        </div>
        
        {!gradingResult && (
          <div className="border-2 border-dashed border-indigo-200 bg-indigo-50 rounded-xl p-6 md:p-10 text-center space-y-4">
             <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm text-indigo-500">
               <Upload size={32} />
             </div>
             <div>
               <h3 className="text-lg font-medium text-indigo-900">Upload Student Test</h3>
               <p className="text-slate-500 text-sm">Upload one or multiple pages (images).</p>
             </div>
             <div className="relative inline-block w-full md:w-auto">
               <button className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors w-full md:w-auto">
                 Select Files
               </button>
               <input 
                  type="file" 
                  multiple 
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={(e) => setStudentFiles(Array.from(e.target.files || []))}
                />
             </div>
             {studentFiles.length > 0 && (
               <div className="mt-4 p-4 bg-white rounded border border-indigo-100 text-left">
                  <p className="font-semibold text-sm text-slate-700 mb-2">Selected Files:</p>
                  {studentFiles.map((f, i) => (
                    <div key={i} className="text-xs text-slate-500 flex items-center gap-2 truncate">
                      <FileText size={12}/> <span className="truncate">{f.name}</span>
                    </div>
                  ))}
                  <button 
                    onClick={handleGradeStudent}
                    disabled={isGrading}
                    className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white py-3 rounded font-medium flex justify-center items-center gap-2 disabled:opacity-50"
                  >
                    {isGrading ? <Loader2 className="animate-spin" /> : <CheckCircle size={18} />}
                    {isGrading ? 'AI is Grading...' : 'Grade Now'}
                  </button>
               </div>
             )}
          </div>
        )}

        {/* Display uploaded images if grading is done or in progress */}
        {studentFiles.length > 0 && (
          <div className="mt-8 grid grid-cols-1 gap-4">
            {studentFiles.map((file, idx) => (
              <div key={idx} className="relative group rounded-lg overflow-hidden border shadow-sm">
                <img 
                  src={URL.createObjectURL(file)} 
                  alt={`page-${idx}`} 
                  className="w-full h-auto"
                />
                <div className="absolute top-2 left-2 bg-black/50 text-white text-xs px-2 py-1 rounded">
                  Page {idx + 1}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Right: Output */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-slate-50 min-h-[50vh]">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Grading Report</h2>
        
        {isGrading && (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <Loader2 size={48} className="animate-spin text-indigo-500 mb-4" />
            <p>Analyzing handwriting...</p>
            <p>Checking logic against answer key...</p>
            <p>Calculating score...</p>
          </div>
        )}

        {!isGrading && !gradingResult && (
          <div className="flex flex-col items-center justify-center h-48 md:h-64 text-slate-400 border border-slate-200 rounded-xl bg-white border-dashed text-sm md:text-base p-4 text-center">
            <p>Results will appear here after grading.</p>
            <p className="text-xs mt-2 md:hidden">(Scroll up to upload)</p>
          </div>
        )}

        {gradingResult && (
          <div className="space-y-6 animate-fade-in pb-10">
            {/* Score Card */}
            <div className="bg-white p-4 md:p-6 rounded-xl shadow-lg border-t-4 border-indigo-500">
               <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xs md:text-sm font-bold text-slate-400 uppercase tracking-wider">Student Name</h3>
                    <p className="text-xl md:text-2xl font-bold text-slate-800">{gradingResult.studentName || 'Unknown'}</p>
                  </div>
                  <div className="text-right">
                    <h3 className="text-xs md:text-sm font-bold text-slate-400 uppercase tracking-wider">Final Grade</h3>
                    <p className="text-3xl md:text-4xl font-extrabold text-indigo-600">{gradingResult.finalGrade}</p>
                  </div>
               </div>
               
               <div className="flex items-end gap-2 mb-4">
                  <span className="text-2xl md:text-3xl font-bold text-slate-800">{gradingResult.totalScore}</span>
                  <span className="text-sm md:text-lg text-slate-400 mb-1">/ {gradingResult.maxTotalScore} pts</span>
                  <span className="ml-auto text-sm md:text-lg font-medium text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                    {gradingResult.percentage}%
                  </span>
               </div>
               
               <div className="bg-indigo-50 p-4 rounded-lg text-indigo-900 text-sm">
                 <strong>Overall Feedback:</strong> {gradingResult.summaryFeedback}
               </div>
            </div>

            {/* Detailed Breakdown */}
            <div className="space-y-3">
              <h3 className="font-semibold text-slate-700">Question Breakdown</h3>
              {gradingResult.questionDetails.map((q, i) => (
                <div key={i} className={`bg-white p-4 rounded-lg shadow-sm border-l-4 ${q.isCorrect ? 'border-green-500' : q.score > 0 ? 'border-yellow-400' : 'border-red-500'}`}>
                  <div className="flex justify-between mb-2">
                    <span className="font-bold text-slate-700">Q{q.questionNumber}</span>
                    <span className="text-sm font-medium">
                      {q.score} / {q.maxScore} pts
                    </span>
                  </div>
                  <div className="text-sm mb-2">
                    <span className="text-slate-500">Answered: </span>
                    <span className="text-slate-800 font-medium break-words">{q.studentAnswer}</span>
                  </div>
                  <p className="text-xs text-slate-500 italic border-t pt-2 mt-2">
                    Feedback: {q.feedback}
                  </p>
                </div>
              ))}
            </div>

            <button 
              onClick={handleNextStudent}
              className="w-full py-4 bg-slate-800 hover:bg-slate-900 text-white rounded-xl shadow-lg font-bold flex items-center justify-center gap-2 transition-transform active:scale-95"
            >
              Finish & Grade Next Student <ChevronRight />
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-50 font-sans">
      {/* Mobile Menu Toggle - Absolute to stay on top */}
      <button 
        onClick={() => setIsSidebarOpen(true)}
        className="absolute top-4 left-4 z-20 p-2 bg-white rounded shadow-md text-slate-700 md:hidden hover:bg-slate-50"
        aria-label="Open Menu"
      >
        <Menu size={20} />
      </button>

      <Sidebar />

      <main className="flex-1 relative overflow-hidden h-full">
        {mode === AppMode.DASHBOARD && renderDashboard()}
        {mode === AppMode.CREATE_TEST && renderCreateTest()}
        {mode === AppMode.SETUP_GRADING && renderSetupGrading()}
        {mode === AppMode.GRADING_SESSION && renderGradingSession()}
      </main>
    </div>
  );
};

export default App;