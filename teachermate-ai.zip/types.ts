export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  CREATE_TEST = 'CREATE_TEST',
  SETUP_GRADING = 'SETUP_GRADING',
  GRADING_SESSION = 'GRADING_SESSION',
}

export interface GradingScaleItem {
  minPercentage: number;
  maxPercentage: number;
  grade: string;
  label?: string; // e.g., "A", "F", "Celujący"
}

export interface QuestionResult {
  questionNumber: string;
  studentAnswer: string;
  isCorrect: boolean;
  score: number;
  maxScore: number;
  feedback: string;
}

export interface GradingResult {
  studentName?: string; // Optional, if AI can read it
  totalScore: number;
  maxTotalScore: number;
  percentage: number;
  finalGrade: string;
  summaryFeedback: string;
  questionDetails: QuestionResult[];
}

export interface ExamContext {
  id: string;
  title: string;
  gradingScale: GradingScaleItem[];
  answerKeyText?: string;
  answerKeyFile?: string; // Base64
  materialText?: string;
}

export interface ChatMessage {
  role: 'user' | 'ai';
  content: string;
}
