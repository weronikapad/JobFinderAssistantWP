import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GradingScaleItem, GradingResult } from "../types";

// Initialize Gemini Client
// Note: API Key must be in process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const gradingSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    studentName: { type: Type.STRING, description: "Name of the student found on the paper, or 'Unknown'" },
    totalScore: { type: Type.NUMBER, description: "Total points earned" },
    maxTotalScore: { type: Type.NUMBER, description: "Maximum possible points for the test" },
    percentage: { type: Type.NUMBER, description: "Percentage score (0-100)" },
    summaryFeedback: { type: Type.STRING, description: "Overall feedback for the student in the language of the test" },
    questionDetails: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          questionNumber: { type: Type.STRING },
          studentAnswer: { type: Type.STRING, description: "Transcribed answer" },
          isCorrect: { type: Type.BOOLEAN },
          score: { type: Type.NUMBER },
          maxScore: { type: Type.NUMBER },
          feedback: { type: Type.STRING, description: "Specific feedback for this question" },
        },
        required: ["questionNumber", "score", "maxScore", "isCorrect"]
      }
    }
  },
  required: ["totalScore", "maxTotalScore", "percentage", "questionDetails"]
};

export const generateTestFromMaterial = async (
  topic: string,
  materialText: string,
  difficulty: string
): Promise<{ testContent: string; answerKey: string }> => {
  const model = "gemini-3-pro-preview"; // Using Pro for better reasoning in creation
  
  const prompt = `
  You are an expert teacher. Create a comprehensive exam based on the provided material.
  
  Topic: ${topic}
  Difficulty: ${difficulty}
  Material:
  ${materialText.substring(0, 20000)} (truncated if too long)

  Output Format:
  Please provide the response in a structured JSON format with two fields:
  1. "testContent": The formatted test ready to be printed (Markdown).
  2. "answerKey": A detailed answer key for the teacher to use for grading.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          testContent: { type: Type.STRING },
          answerKey: { type: Type.STRING },
        }
      }
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  return JSON.parse(text);
};

export const gradeStudentTest = async (
  answerKey: string,
  answerKeyImages: string[],
  studentImages: string[],
  gradingScale: GradingScaleItem[]
): Promise<GradingResult> => {
  const model = "gemini-2.5-flash"; // Flash is excellent for multimodal tasks like this
  
  const scaleDescription = gradingScale
    .map(s => `${s.minPercentage}%-${s.maxPercentage}%: ${s.grade} (${s.label || ''})`)
    .join("; ");

  const parts: any[] = [];

  // 1. Add Answer Key Context
  if (answerKey) {
    parts.push({ text: `ANSWER KEY TEXT:\n${answerKey}` });
  }
  
  // 2. Add Answer Key Images (if provided)
  answerKeyImages.forEach(img => {
    parts.push({ inlineData: { mimeType: 'image/jpeg', data: img } });
    parts.push({ text: "[Above is an image of the Answer Key]" });
  });

  // 3. Add Student Test Images
  studentImages.forEach(img => {
    parts.push({ inlineData: { mimeType: 'image/jpeg', data: img } });
    parts.push({ text: "[Above is a page of the Student's Test Submission]" });
  });

  // 4. Instructions
  const prompt = `
    Role: You are an expert teacher grading a student's exam.
    
    Task:
    1. Analyze the 'Student Test Submission' images to identify questions and handwritten answers.
    2. Compare them against the provided 'Answer Key' (Text or Images).
    3. Grade each question. 
       - For objective questions (math, multiple choice), be precise.
       - For open-ended questions, evaluate based on understanding, logic, and correctness relative to the key. You do not need an exact match if the logic is sound.
    4. Calculate the total score and percentage.
    5. Determine the final grade based on this Grading Scale: [ ${scaleDescription} ].

    Output:
    Return a JSON object matching the schema provided. 
    Ensure the 'finalGrade' strictly follows the grading scale provided based on the percentage.
  `;
  
  parts.push({ text: prompt });

  const response = await ai.models.generateContent({
    model,
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: gradingSchema,
      temperature: 0.2, // Low temperature for consistent grading
    }
  });

  const text = response.text;
  if (!text) throw new Error("Failed to grade test");

  const result = JSON.parse(text) as GradingResult;
  
  // Post-processing to ensure grade string matches exactly if the AI got creative
  const matchedScale = gradingScale.find(s => result.percentage >= s.minPercentage && result.percentage <= s.maxPercentage);
  if (matchedScale) {
      result.finalGrade = matchedScale.grade; // Force strict adherence
  }

  return result;
};
